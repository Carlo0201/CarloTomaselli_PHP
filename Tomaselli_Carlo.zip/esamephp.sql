-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 31, 2022 alle 16:07
-- Versione del server: 10.4.22-MariaDB
-- Versione PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esamephp`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `ingredienti`
--

CREATE TABLE `ingredienti` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `quantita` int(11) NOT NULL,
  `unita_misura` varchar(10) NOT NULL,
  `id_utente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `ingredienti`
--

INSERT INTO `ingredienti` (`id`, `nome`, `quantita`, `unita_misura`, `id_utente`) VALUES
(77, 'Mele', 700, 'grammi', 1),
(78, 'Zucchero', 200, 'grammi', 1),
(79, 'Farina', 250, 'grammi', 1),
(80, 'Burro', 110, 'grammi', 1),
(82, 'Farina', 250, 'grammi', 6),
(83, 'Zucchero a velo', 100, 'grammi', 6),
(84, 'Burro', 150, 'grammi', 6),
(85, 'Fragole', 250, 'grammi', 6),
(86, 'Kiwi', 100, 'grammi', 6),
(87, 'Mirtilli', 20, 'grammi', 6),
(88, 'Lamponi', 20, 'grammi', 6);

-- --------------------------------------------------------

--
-- Struttura della tabella `ingredienti_ricetta`
--

CREATE TABLE `ingredienti_ricetta` (
  `id` int(11) NOT NULL,
  `id_ricetta` int(11) NOT NULL,
  `id_ingrediente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `ingredienti_ricetta`
--

INSERT INTO `ingredienti_ricetta` (`id`, `id_ricetta`, `id_ingrediente`) VALUES
(329654, 31, 77),
(329655, 31, 78),
(329656, 31, 79),
(329657, 31, 80),
(329659, 32, 82),
(329660, 32, 83),
(329661, 32, 84),
(329662, 32, 85),
(329663, 32, 86),
(329664, 32, 87),
(329665, 32, 88);

-- --------------------------------------------------------

--
-- Struttura della tabella `ricette`
--

CREATE TABLE `ricette` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `difficolta` int(11) NOT NULL,
  `descrizione` varchar(500) NOT NULL,
  `porzioni` int(11) NOT NULL,
  `id_utente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `ricette`
--

INSERT INTO `ricette` (`id`, `nome`, `difficolta`, `descrizione`, `porzioni`, `id_utente`) VALUES
(31, 'Torta di Mele', 2, 'Le mele da sempre sono protagoniste indiscusse dei dolci casalinghi, come la nostra torta di mele, golosa, soffice e aromatica, è il miglior comfort food che si possa desiderare!', 8, 1),
(32, 'Crostata alla frutta', 3, 'Tra tutti i dolci esistenti sicuramente la crostata alla frutta è il dolce classico e intramontabile di diritto.', 8, 6);

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cognome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `nome`, `cognome`, `email`, `password`) VALUES
(1, 'admin', 'admin', 'admin', '$2y$10$mKogUq6x6Ges5PP//B1TcuirDg3314VbK6XxNgwKYZnNxJP6oWvfe'),
(6, 'root', 'root', 'root', '$2y$10$M1QZ45DUGPwnYlDA4SwMde1XX0pZrHnV6t9FUDF/9RGRnm2USiwNi'),
(7, 'root', 'root', 'root1', '$2y$10$uQMIkFI1S0B1en7glpHE9e4w7soMbBWkYCDC9sHrUidbQxqU5k.1u');

-- --------------------------------------------------------

--
-- Struttura della tabella `voti_ricette`
--

CREATE TABLE `voti_ricette` (
  `id` int(11) NOT NULL,
  `id_utente` int(11) NOT NULL,
  `id_ricetta` int(11) NOT NULL,
  `voto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `voti_ricette`
--

INSERT INTO `voti_ricette` (`id`, `id_utente`, `id_ricetta`, `voto`) VALUES
(3, 6, 31, 4),
(4, 6, 32, 5),
(5, 1, 31, 3),
(6, 1, 32, 5);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `ingredienti`
--
ALTER TABLE `ingredienti`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `ingredienti_ricetta`
--
ALTER TABLE `ingredienti_ricetta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `INGREDIENTE_FK` (`id_ingrediente`),
  ADD KEY `RICETTA_FK` (`id_ricetta`);

--
-- Indici per le tabelle `ricette`
--
ALTER TABLE `ricette`
  ADD PRIMARY KEY (`id`),
  ADD KEY `UTENTE_FK` (`id_utente`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `voti_ricette`
--
ALTER TABLE `voti_ricette`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `ingredienti`
--
ALTER TABLE `ingredienti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT per la tabella `ingredienti_ricetta`
--
ALTER TABLE `ingredienti_ricetta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=329666;

--
-- AUTO_INCREMENT per la tabella `ricette`
--
ALTER TABLE `ricette`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT per la tabella `voti_ricette`
--
ALTER TABLE `voti_ricette`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `ingredienti_ricetta`
--
ALTER TABLE `ingredienti_ricetta`
  ADD CONSTRAINT `INGREDIENTE_FK` FOREIGN KEY (`id_ingrediente`) REFERENCES `ingredienti` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `RICETTA_FK` FOREIGN KEY (`id_ricetta`) REFERENCES `ricette` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `ricette`
--
ALTER TABLE `ricette`
  ADD CONSTRAINT `UTENTE_FK` FOREIGN KEY (`id_utente`) REFERENCES `utenti` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
