<?php
class Ingrediente
{

    public $id;
    public $nome;
    public $quantita;
    public $unita_misura;

    function __construct($id, $nome, $quantita, $unita_misura)
    {
        $this->id = $id;
        $this->nome = $nome;
        $this->quantita = $quantita;
        $this->unita_misura = $unita_misura;
    }

    function get_nome()
    {
        return $this->nome;
    }

    function get_id()
    {
        return $this->id;
    }

    function get_quantita()
    {
        return $this->quantita;
    }

    function get_unita_misura()
    {
        return $this->unita_misura;
    }
}
