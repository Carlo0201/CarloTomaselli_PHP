<?php

require '../db.php';
require '../header.php';
require '../check_auth.php';

$query = 'SELECT * FROM ingredienti WHERE id_utente='.$_SESSION['id_utente'];

$res = $db->query($query);

?>

<div class="content">
    <h1>Elenco Ingredienti</h1>

    <a href="/ingredienti/modifica.php?id=0" type="button" class="btn btn-success" style="margin: 12px 4px;">Aggiungi ingrediente</a>

    <?php
    if (isset($_SESSION['messaggio'])) {
        echo "<div class=\"alert alert-success\" role=\"alert\" style=\"max-width: 300px\">";
        echo $_SESSION['messaggio'];
        echo "</div>";
        unset($_SESSION['messaggio']);
    }
    ?>

    <table class="table table-bordered" style="max-width: 800px; margin: 4px">
        <tr>
            <th>Nome</th>
            <th>Quantità</th>
            <th>Unita di misura</th>
        </tr>
        <?php
        while ($riga = $res->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $riga['nome'] . "</td>";
            echo "<td>" . $riga['quantita'] . "</td>";
            echo "<td>" . $riga['unita_misura'] . "</td>";

        ?>
            <td>
                <a href="/ingredienti/modifica.php?id=<?= $riga['id'] ?>" type="button" class="btn btn-secondary">Modifica</a>
                <a href="/ingredienti/elimina.php?id=<?= $riga['id'] ?>" type="button" class="btn btn-danger">Elimina</a>
            </td>
        <?php
            echo "</tr>";
        }
        ?>
    </table>
</div>