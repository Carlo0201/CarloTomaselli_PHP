<?php

require '../db.php';
require '../header.php';
require '../check_auth.php';
require 'ingrediente.php';

if (isset($_GET['id']) && $_GET['id'] > 0) {
    $stmt = $db->prepare('SELECT * FROM ingredienti WHERE id = ?');
    $stmt->bind_param('i', $_GET['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    if ($result->num_rows === 1) {
        $array = $result->fetch_assoc();
        $ingrediente=new Ingrediente($array['id'],$array['nome'],$array['quantita'],$array['unita_misura']);
    } else {
        // TODO: mostrare errore all'utente
        header('Location: /ingredienti');
    }
}

if (isset($_POST['pulsante'])) {
    $stmt = $db->prepare('DELETE FROM ingredienti WHERE id = ?');
    $stmt->bind_param('i', $ingrediente->get_id());
    $stmt->execute();
    $stmt->close();

    // TODO: mostrare messaggio conferma all'utente
    header('Location: /ingredienti');
    die;
}

?>

<style>
input {
    margin-bottom: 6px;
}
.form-group {
    max-width: 500px;
}
</style>

<div class="content">
    <h1>Elimina ingrediente</h1>

    <p>
        Sei sicuro di volere eliminare l'ingrediente <?= $ingrediente->get_nome()?>?
    </p>

    <form method="POST">
        <div class="form-group">
            <input class="form-control btn btn-danger" type="submit" name="pulsante" value="Elimina" />
        </div>
    </form>

</div>
