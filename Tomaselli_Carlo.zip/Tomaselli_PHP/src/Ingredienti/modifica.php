<?php

require '../db.php';
require '../header.php';
require '../check_auth.php';
require 'ingrediente.php';

$ingrediente = new Ingrediente(0, "", "", "");

if (isset($_GET['id']) && $_GET['id'] > 0) {
    $stmt = $db->prepare('SELECT * FROM ingredienti WHERE id = ?');
    $stmt->bind_param('i', $_GET['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    if ($result->num_rows === 1) {
        $array = $result->fetch_assoc();
        $ingrediente = new Ingrediente($array['id'], $array['nome'], $array['quantita'], $array['unita_misura']);
    }
}

if (isset($_POST['pulsante'])) {

    if ($ingrediente->get_id() === 0) {
        $stmt = $db->prepare('INSERT INTO ingredienti (nome, quantita, unita_misura) VALUES (?, ?, ?)');
        $stmt->bind_param('sis', $_POST['nome'], $_POST['quantita'], $_POST['unita_misura']);
        //  $messaggio = ucfirst(TIPO_PERSONA) . ' aggiunto con successo';
    } else {
        $stmt = $db->prepare('UPDATE ingredienti SET nome = ?, quantita = ?, unita_misura = ? WHERE id = ?');
        $stmt->bind_param('sisi', $_POST['nome'],  $_POST['quantita'], $_POST['unita_misura'], $ingrediente->get_id());
        // $messaggio = ucfirst(TIPO_PERSONA) .' modificato con successo';
    }

    $stmt->execute();
    $stmt->close();

    // $_SESSION['messaggio'] = $messaggio;

    header('Location: /ingredienti/index.php');
    die;
}

?>

<style>
    input {
        margin-bottom: 6px;
    }

    .form-group {
        max-width: 500px;
    }
</style>

<div class="content">

    <h1><?= ($ingrediente->get_id() === 0 ? 'Aggiungi' : 'Modifica') ?> ingrediente</h1>

    <form method="POST">
        <div class="form-group">
            <input class="form-control" type="text" name="nome" placeholder="Nome" value="<?= $ingrediente->get_nome() ?>" />
            <input class="form-control" type="number" name="quantita" placeholder="Quantita" value="<?= $ingrediente->get_quantita() ?>" />
            <select class="form-control form-select" name="unita_misura">
                <option value="grammi">Grammi</option>
                <option value="litri">Litri</option>
                <option value="cucchiai">Cucchiai</option>
            </select>
            <input class="form-control btn btn-success" type="submit" name="pulsante" value="Salva" />
        </div>
    </form>

</div>