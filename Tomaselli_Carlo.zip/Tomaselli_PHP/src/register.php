<?php

require 'db.php';
require 'header.php';

//session_start();

if (isset($_POST['pulsante'])) {

    if (
        isset($_POST['name']) && isset($_POST['surname']) && isset($_POST['email']) && isset($_POST['password'])
        && $_POST['name'] != "" && $_POST['surname'] != "" && $_POST['email'] != "" && $_POST['password'] != ""
    ) {
        $name = $_POST['name'];
        $surname = $_POST['surname'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        $stmt = $db->prepare('SELECT * FROM utenti WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();

        if ($result->num_rows === 1) {
            echo 'Email già utilizzata';
            // l'utente è stato trovato

        } else {
            $stmt = $db->prepare("INSERT INTO `utenti`(`nome`, `cognome`, `email`, `password`) VALUES (?,?,?,?)");

            //('" . $name . "','" . $surname . "','" . $email . "','" . password_hash($password, PASSWORD_BCRYPT) . "')");
            $passwordCrypt=password_hash($password, PASSWORD_BCRYPT);
            $stmt->bind_param('ssss', $name, $surname, $email, $passwordCrypt);
            $stmt->execute();
            echo 'Utente registrato';
        }
    } else {
        echo "Inserire tutti i valori";
    }
}

?>
<style>
    .content {
        max-width: 400px;
    }

    input {
        margin-bottom: 8px;
    }
</style>

<div class="content">
    <h1>Registrazione</h1>

    <form method="POST">
        <div class="form-group">
            <input class="form-control" type="text" name="name" placeholder="Name" />
            <input class="form-control" type="text" name="surname" placeholder="Surname" />
            <input class="form-control" type="text" name="email" placeholder="Email" />
            <input class="form-control" type="password" name="password" placeholder="Password" />
            <input class="form-control btn btn-success" type="submit" name="pulsante" value="Registrati" />
            <a href="logout.php">Login</a>
        </div>
    </form>
</div>