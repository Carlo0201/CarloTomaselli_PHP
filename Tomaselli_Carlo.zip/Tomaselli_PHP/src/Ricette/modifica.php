<?php

require '../db.php';
require '../header.php';
require '../check_auth.php';
require '../Ingredienti/ingrediente.php';
require_once 'ricetta.php';

$ricetta = new Ricetta(0, "", "", "", "");
$count = 0;
if (isset($_GET['id']) && $_GET['id'] > 0) {
    $stmt = $db->prepare('SELECT * FROM ricette WHERE id = ?');
    $stmt->bind_param('i', $_GET['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    $query1 = "SELECT * FROM `ingredienti`INNER JOIN ingredienti_ricetta ON ingredienti_ricetta.id_ingrediente=ingredienti.id WHERE ingredienti_ricetta.id_ricetta=" . $_GET['id'];
    $res1 = $db->query($query1);
    $count = $res1->num_rows;
    error_log("NUMROWS: " . $count);


    if ($result->num_rows === 1) {
        $array = $result->fetch_assoc();
        $ricetta = new Ricetta($array['id'], $array['nome'], $array['difficolta'], $array['descrizione'], $array['porzioni']);
    }
}

if (isset($_POST['submit'])) {

    if ($ricetta->get_id() === 0) {
        $stmt = $db->prepare('INSERT INTO ricette (nome, difficolta, descrizione, porzioni, id_utente) VALUES (?, ?, ?, ?,?)');
        $stmt->bind_param('sisii', $_POST['nomericetta'], $_POST['difficolta'], $_POST['descrizione'], $_POST['porzioni'],$_SESSION['id_utente']);
        $stmt->execute();
        $id_ricetta = $stmt->insert_id;
        error_log("id_ricetta= " . $id_ricetta);
        error_log(count($_POST['nome']));
        $i = 0;
        foreach ($_POST['nome'] as $value) {
            //for ($i = 0; $i <= (count($_POST['nome'])); $i++) {
            error_log($value);
            error_log($_POST['quantita'][$i]);
            error_log($_POST['misura'][$i]);
            $id_ingrediente;
            $stmt = $db->prepare('INSERT INTO ingredienti (nome, quantita, unita_misura, id_utente) VALUES (?, ?, ?,?)');
            $stmt->bind_param('sisi', $_POST['nome'][$i], $_POST['quantita'][$i], $_POST['misura'][$i],$_SESSION['id_utente']);
            $stmt->execute();
            $id_ingrediente = $stmt->insert_id;
            $stmt = $db->prepare('INSERT INTO ingredienti_ricetta (id_ricetta, id_ingrediente) VALUES (?, ?)');
            $stmt->bind_param('ii', $id_ricetta, $id_ingrediente);
            $stmt->execute();
            $i++;
        }


        //  $messaggio = ucfirst(TIPO_PERSONA) . ' aggiunto con successo';
    } else {
        error_log("COUNT: " . count($_POST));

        $stmt = $db->prepare('UPDATE ricette SET nome = ?, difficolta = ?, descrizione = ?, porzioni = ? WHERE id = ?');
        $stmt->bind_param('sisii', $_POST['nomericetta'],  $_POST['difficolta'], $_POST['descrizione'], $_POST['porzioni'], $ricetta->get_id());
        $stmt->execute();

        $ids;
        $idsPage;
        $ind = 0;
        $indPage = 0;


        while ($riga1 = $res1->fetch_assoc()) {
            $ids[$ind] = $riga1['id_ingrediente'];
            $ind++;
        }
        foreach ($ids as $value) {
            error_log($value);
        }

        foreach ($_POST['id'] as $value) {
            $idsPage[$indPage] = $value;
            $indPage++;
            error_log($value);
        }

        foreach ($ids as $value) {
            if (!in_array($value, $idsPage)) {
                error_log("NO " . $value);
                $stmt = $db->prepare('DELETE FROM ingredienti_ricetta WHERE id_ingrediente = ? AND id_ricetta=?');
                $stmt->bind_param('ii', $value, $_GET['id']);
                $stmt->execute();
            }
        }

        $i = 0;
        foreach ($_POST['id'] as $id) {
            // for ($i = 1; $i <= ((count($_POST) - 5) / 4); $i++) {
            //error_log($i);
            if (isset($id) && $id != "") {
                $stmt = $db->prepare('UPDATE ingredienti SET nome = ?, quantita = ?, unita_misura = ? WHERE id = ?');
                $stmt->bind_param('sisi', $_POST['nome'][$i],  $_POST['quantita'][$i], $_POST['misura'][$i], $id);
                $stmt->execute();
                //} elseif(){

            } else {
                $stmt = $db->prepare('INSERT INTO ingredienti (nome, quantita, unita_misura,id_utente) VALUES (?, ?, ?,?)');
                $stmt->bind_param('sisi', $_POST['nome'][$i], $_POST['quantita'][$i], $_POST['misura'][$i],$_SESSION['id_utente']);
                $stmt->execute();
                $id_ingrediente = $stmt->insert_id;
                $stmt = $db->prepare('INSERT INTO ingredienti_ricetta (id_ricetta, id_ingrediente) VALUES (?, ?)');
                $stmt->bind_param('ii', $_GET['id'], $id_ingrediente);
                $stmt->execute();
            }
            $i++;
        }
    }

    //$stmt->execute();
    error_log("close");
    $stmt->close();

    // $_SESSION['messaggio'] = $messaggio;

    header('Location: /ricette/index.php');
    die;
}

?>

<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>

<style>
    input {
        margin-bottom: 6px;
    }

    .form-group {
        max-width: 500px;
    }
</style>

<div class="content">

    <h1><?= ($ricetta->get_id() === 0 ? 'Aggiungi' : 'Modifica') ?> ricetta</h1>

    <form method="POST">
        <div class="form-group" style="max-width: 900px;">
            <input class="form-control" type="text" name="nomericetta" placeholder="Nome" value="<?= $ricetta->get_nome() ?>" />
            <input class="form-control" type="number" max="5" min="1" name="difficolta" placeholder="Difficoltà" value="<?= $ricetta->get_difficolta() ?>" />
            <input class="form-control" type="text" name="descrizione" placeholder="Descrizione" value="<?= $ricetta->get_descrizione() ?>" />
            <input class="form-control" type="number" name="porzioni" placeholder="Porzioni" value="<?= $ricetta->get_porzioni() ?>" />

            <div class="table-responsive">
                <table class="table table-bordered" id="dynamic_field">
                    <?php
                    if ($count != 0) {
                        $index = 0;
                        while ($riga1 = $res1->fetch_assoc()) {

                            //echo $riga1['nome'] . " | ";
                            echo "<tr id='row" . ($index + 1) . "'>";
                            echo '<td><input type="text" name="id[]" placeholder="ID" class="form-control name_list" value="' .  $riga1['id_ingrediente'] . '" readonly></input></td>';
                            echo '<td><input type="text" name="nome[]" placeholder="Nome ingrediente" class="form-control name_list" value="' .  $riga1['nome'] . '"></input></td>';
                            echo '<td><input type="number" name="quantita[]" placeholder="Quantità" class="form-control name_list" value="' . $riga1['quantita'] . '"></input></td>';
                            echo '<td><select class="form-control form-select" name="misura[]">
                            <option value="grammi">Grammi</option>
                            <option value="litri">Litri</option>
                            <option value="cucchiai">Cucchiai</option>
                          </select></td>';
                            //echo '<td><input type="text" name="misura[]" placeholder="Unità di misura" class="form-control name_list" value="' . $riga1['unita_misura'] . '"></input></td>';
                            if ($index == 0) {
                                echo '<td><button type="button" name="add" id="add" class="btn btn-success">+</button></td>';
                            } else {
                                echo '<td><button type="button" name="remove' . ($index + 1) . '" id="' . ($index + 1) . '" class="btn btn-danger btn_remove" value="' . $riga1['id_ingrediente'] . '">X</button></td>';
                            }
                            echo "</tr>";
                            $index++;
                        }
                    } else {

                        echo "<tr>";
                        echo '<td><input type="text" name="id[]" placeholder="ID" class="form-control name_list" readonly></input></td>';
                        echo '  <td><input type="text" name="nome[]" placeholder="Nome ingrediente" class="form-control name_list" /></td>';
                        echo '  <td><input type="number" name="quantita[]" placeholder="Quantita" class="form-control name_list" /></td>';
                        echo '  <td><select class="form-control form-select" name="misura[]">
                        <option value="grammi">Grammi</option>
                        <option value="litri">Litri</option>
                        <option value="cucchiai">Cucchiai</option>
                      </select></td>';
                        echo '<td><button type="button" name="add" id="add" class="btn btn-success">+</button></td>';
                        echo '</tr>';
                    }
                    ?>
                </table>

            </div>
            <input class="form-control btn btn-success" type="submit" id="submit" name="submit" value="Salva" />
        </div>
    </form>

</div>

<script>
    $(document).ready(function() {
                var i = <?= $count ?>;
                $('#add').click(function() {
                        i++;
                        $('#dynamic_field').append('<tr id="row' + i + '"><td><input type="text" name="id[]" placeholder="ID" class="form-control name_list" value="" readonly></input></td><td><input type="text" name="nome[]" placeholder="Nome ingrediente" class="form-control name_list" /></td><td><input type="number" name="quantita[]" placeholder="Quantità" class="form-control name_list" /></td><td><select class="form-control form-select" name="misura[]"> <option value = "grammi" > Grammi </option> <option value = "litri" > Litri </option> <option value = "cucchiai" > Cucchiai </option> </select></td > < td > < button type = "button"name = "remove"id = "' + i + '"class = "btn btn-danger btn_remove" > X < /button></td > < /tr>');});

                    $(document).on('click', '.btn_remove', function() {
                        var button_id = $(this).attr("id");
                        $('#row' + button_id + '').remove();
                    });

                    /* $('#submit').click(function() {
                         console.log("ciao");
                         $.ajax({
                             url: "modifica.php",
                             method: "POST",
                             data: $('#add_name').serialize(),
                             success: function(data) {
                                 alert(data);
                                 $('#add_name')[0].reset();
                             }
                         });
                     });*/

                });
</script>