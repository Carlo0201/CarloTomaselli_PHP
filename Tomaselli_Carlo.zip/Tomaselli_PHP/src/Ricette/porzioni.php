<?php

require '../db.php';
require '../header.php';
//require '../check_auth.php';
require 'ricetta.php';
require '../Ingredienti/ingrediente.php';

$query = 'SELECT * FROM ricette WHERE id=' . $_GET['id'];

$res = $db->query($query);
$ricetta;

while ($riga = $res->fetch_assoc()) {
    //echo $riga['nome'];
    $ricetta = new Ricetta($riga['id'], $riga['nome'], $riga['difficolta'], $riga['descrizione'], $riga['porzioni']);
}

if (isset($_GET['porzioni']) && $_GET['porzioni'] != "") {
    $query1 = "SELECT * FROM `ingredienti`INNER JOIN ingredienti_ricetta ON ingredienti_ricetta.id_ingrediente=ingredienti.id WHERE ingredienti_ricetta.id_ricetta=" . $_GET['id'];
    $res1 = $db->query($query1);
    $ingredienti;
    $i = 0;
    $ingredienti_porzione;
    while ($riga = $res1->fetch_assoc()) {
        $ingredienti[$i] = new Ingrediente($riga['id_ingrediente'], $riga['nome'], $riga['quantita'], $riga['unita_misura']);
        $i++;
    }
    $j = 0;
    foreach ($ingredienti as $ingrediente) {
        $quantita_uno = ($ingrediente->get_quantita() / $ricetta->get_porzioni());
        $ingrediente_porzione[$j] = new Ingrediente($ingrediente->get_id(), $ingrediente->get_nome(), ($quantita_uno * $_GET['porzioni']), $ingrediente->get_unita_misura());
        $j++;
    }
}
?>



<div class="content">
    <h1>
        <?= $ricetta->get_nome(); ?>
    </h1>
    <form action="porzioni.php" method="GET">
        <div class="form-group" style="max-width: 500px;">
            <label>ID:</label>
            <input type="number" name="id" class="form-control" value="<?= $ricetta->get_id() ?>" readonly />
            <label>NUMERO PORZIONI:</label>
            <input type="number" name="porzioni" class="form-control" placeholder="Numero porzioni">
            <button type="submit" class="btn btn-success" style="margin-top:10px">CALCOLA</button>
        </div>
    </form>
    <?php
    if (isset($_GET['porzioni']) && $_GET['porzioni'] != "") {
        echo '<table class="table table-bordered" style="max-width: 800px; margin: 4px">';
        echo '<tr>';
        echo '<th>Nome</th>';
        echo '<th>Quantità</th>';
        echo '<th>Unita di misura</th>';
        echo '</tr>';
        foreach ($ingrediente_porzione as $ingrediente) {
            echo "<tr>";
            echo "<td>" . $ingrediente->get_nome() . "</td>";
            echo "<td>" . number_format($ingrediente->get_quantita(), 2) . "</td>";
            echo "<td>" . $ingrediente->get_unita_misura() . "</td>";
            echo "</tr>";
        }
        echo '</table>';
    }
    ?>
</div>