<?php

require "../header.php";
require "../db.php";

if (isset($_GET['id']) && $_GET['id'] != "") {

    $query = 'SELECT * FROM ricette WHERE id=' . $_GET['id'];


    $res = $db->query($query);

    $query1 = "SELECT * FROM `ingredienti`INNER JOIN ingredienti_ricetta ON ingredienti_ricetta.id_ingrediente=ingredienti.id WHERE ingredienti_ricetta.id_ricetta=" . $_GET['id'];
    $res1 = $db->query($query1);

    while ($riga = $res->fetch_assoc()) {
?>

        <div>
            <h1><?php echo $riga['nome'] ?></h1>
            <h6>Difficoltà: <?php echo $riga['difficolta'] ?> </h6>
            <h6>Porzioni: <?php echo $riga['porzioni'] ?> </h6>
            <h5><?php echo $riga['descrizione'] ?></h5>
            <table class="table table-bordered" style="max-width: 800px; margin: 4px">
                <?php while ($riga1 = $res1->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>'.$riga1['nome'].'</td>';
                    echo '<td>'.$riga1['quantita'].'</td>';
                    echo '<td>'.$riga1['unita_misura'].'</td>';
                    echo '</tr>';
                }
                ?>
            </table>
        </div>
        <form action="voto.php">
            <label>ID RICETTA</label>
            <input type="number" name=id_ricetta value="<?php echo $riga['id'] ?>" readonly>
            </br>
            <label>VOTO</label>
            <input type="number" name="voto" max="5" min="1">
            <input type="submit" name="submit">
        </form>

<?php
    }
} else {
    header('Location: ../index.php');
}
?>