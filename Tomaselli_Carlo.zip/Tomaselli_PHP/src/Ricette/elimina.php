<?php

require '../db.php';
require '../header.php';
require '../check_auth.php';
require 'ricetta.php';

if (isset($_GET['id']) && $_GET['id'] > 0) {
    $stmt = $db->prepare('SELECT * FROM ricette WHERE id = ?');
    $stmt->bind_param('i', $_GET['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    if ($result->num_rows === 1) {
        $array = $result->fetch_assoc();
        $ricetta=new Ricetta($array['id'],$array['nome'],$array['difficolta'],$array['descrizione'],$array['porzioni']);
    } else {
        // TODO: mostrare errore all'utente
        header('Location: /ricette');
    }
}

if (isset($_POST['pulsante'])) {
    $stmt = $db->prepare('DELETE FROM ricette WHERE id = ?');
    $stmt->bind_param('i', $ricetta->get_id());
    $stmt->execute();
    $stmt->close();

    // TODO: mostrare messaggio conferma all'utente
    header('Location: /ricette');
    die;
}

?>

<style>
input {
    margin-bottom: 6px;
}
.form-group {
    max-width: 500px;
}
</style>

<div class="content">
    <h1>Elimina ricetta</h1>

    <p>
        Sei sicuro di volere eliminare la ricetta <?= $ricetta->get_nome()?>?
    </p>

    <form method="POST">
        <div class="form-group">
            <input class="form-control btn btn-danger" type="submit" name="pulsante" value="Elimina" />
        </div>
    </form>

</div>