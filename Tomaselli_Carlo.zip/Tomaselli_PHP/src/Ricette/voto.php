<?php

require "../header.php";
require "../db.php";

echo $_GET['id_ricetta'];
echo $_GET['voto'];
echo $_SESSION['id_utente'];

if (isset($_SESSION['id_utente']) && isset($_GET['id_ricetta']) && isset($_GET['voto']) && $_SESSION['id_utente'] != "" && $_GET['id_ricetta'] != "" && $_GET['voto'] != "") {


    $stmt = $db->prepare('SELECT * FROM voti_ricette WHERE id_utente=? AND id_ricetta=?');
        $stmt->bind_param('ii',$_SESSION['id_utente'], $_GET['id_ricetta']);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();

        if ($result->num_rows === 1) {
            $riga=$result->fetch_assoc();
            $stmt=$db->prepare('UPDATE `voti_ricette` SET`voto`=? WHERE id=?');
            $stmt->bind_param('ii',$_GET['voto'],$riga['id']);
            $stmt->execute();
            $stmt->close();
            header('Location: /index.php');

        }else{
            
            $stmt=$db->prepare('INSERT INTO `voti_ricette`(`id_utente`, `id_ricetta`, `voto`) VALUES (?,?,?)');
            $stmt->bind_param('iii',$_SESSION['id_utente'],$_GET['id_ricetta'],$_GET['voto']);
            $stmt->execute();
            $stmt->close();
            header('Location: /index.php');

        }
}
else{
    echo "ciao";
}