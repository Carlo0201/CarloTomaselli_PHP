<?php
Class Ricetta{
    
    public $nome;
    public $difficolta;
    public $descrizione;
    public $porzioni;

    function __construct($id, $nome, $difficolta, $descrizione, $porzioni)
    {
        $this->id = $id;
        $this->nome = $nome;
        $this->difficolta = $difficolta;
        $this->descrizione = $descrizione;
        $this->porzioni = $porzioni;
    }

    function get_nome()
    {
        return $this->nome;
    }

    function get_id()
    {
        return $this->id;
    }

    function get_difficolta()
    {
        return $this->difficolta;
    }

    function get_descrizione()
    {
        return $this->descrizione;
    }

    function get_porzioni()
    {
        return $this->porzioni;
    }

}
?>