<?php

require '../db.php';
require '../header.php';
require '../check_auth.php';

$query = 'SELECT * FROM ricette WHERE id_utente=' . $_SESSION['id_utente'];

$res = $db->query($query);

?>

<div class="content">
    <h1>Elenco Ricette</h1>

    <a href="/ricette/modifica.php?id=0" type="button" class="btn btn-success" style="margin: 12px 4px;">Aggiungi Ricetta</a>

    <?php
    if (isset($_SESSION['messaggio'])) {
        echo "<div class=\"alert alert-success\" role=\"alert\" style=\"max-width: 300px\">";
        echo $_SESSION['messaggio'];
        echo "</div>";
        unset($_SESSION['messaggio']);
    }
    ?>

    <table class="table table-bordered" style="margin: 4px">
        <tr>
            <th>Nome</th>
            <th>Difficolta</th>
            <th>Descrizione</th>
            <th>Porzioni</th>
            <th>Ingredienti</th>
            <th>Media Voti</th>
        </tr>
        <?php
        while ($riga = $res->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $riga['nome'] . "</td>";
            echo "<td>" . $riga['difficolta'] . "</td>";
            echo "<td>" . $riga['descrizione'] . "</td>";
            echo "<td>" . $riga['porzioni'] . "</td>";
            $query1 = "SELECT ingredienti.nome FROM `ingredienti`INNER JOIN ingredienti_ricetta ON ingredienti_ricetta.id_ingrediente=ingredienti.id WHERE ingredienti_ricetta.id_ricetta=" . $riga['id'];
            $res1 = $db->query($query1);
            echo "<td>";
            while ($riga1 = $res1->fetch_assoc()) {
                error_log($riga1['nome']);
                echo $riga1['nome'] . " | ";
            }
            echo "</td>";
            $query2 = "SELECT * FROM `voti_ricette` WHERE `id_ricetta`=" . $riga['id'];
            $res2 = $db->query($query2);
            echo "<td>";
            $counter = 0;
            $media = 0;
            while ($riga2 = $res2->fetch_assoc()) {
                $media += $riga2['voto'];
                $counter++;
            }
            if ($counter == 0) {
                echo "0";
            } else {
                echo ($media / $counter);
            }

            echo "</td>";
            // echo "<td>" . $riga['ingredienti'] . "</td>";

        ?>
            <td>
                <a href="/ricette/porzioni.php?id=<?= $riga['id'] ?>" type="button" class="btn btn-secondary">Calcola Porzioni</a>
                <a href="/ricette/modifica.php?id=<?= $riga['id'] ?>" type="button" class="btn btn-secondary">Modifica</a>
                <a href="/ricette/elimina.php?id=<?= $riga['id'] ?>" type="button" class="btn btn-danger">Elimina</a>
                <a href="/ricette/inforicetta.php?id=<?= $riga['id'] ?>" type="button" class="btn btn-secondary">INFO</a>
            </td>
        <?php
            echo "</tr>";
        }
        ?>
    </table>
</div>