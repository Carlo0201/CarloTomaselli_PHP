<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<style>
    .content {
        margin: 16px;
    }
</style>

<head>
    <nav class="navbar navbar-dark bg-dark" style="color: white">
        <a href="/index.php" style="color: #ffffff">Ricettario</a>
        <a href="/ingredienti/index.php" style="color: #ffffff">I miei Ingredienti</a>
        <a href="/ricette/index.php" style="color: #ffffff">Le mie Ricette</a>

        <?php

        session_start();
        if (!isset($_SESSION['id_utente'])) {

            echo ' <a href="/login.php" style="color: #ffffff">Login</a>';
            echo ' <a href="/register.php" style="color: #ffffff">Register</a>';
        }else{
            echo ' <a href="/logout.php" style="color: #ffffff">Logout</a>';
        }
        ?>
    </nav>
</head>