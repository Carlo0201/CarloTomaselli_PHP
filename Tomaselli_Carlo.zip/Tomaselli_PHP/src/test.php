<?php

echo password_hash('admin', PASSWORD_BCRYPT) . PHP_EOL;

die;
$hash = '$2y$10$iY9f3ZmHcHA0JFNPirbfouN45uOaseN.tddokBcP9Lzfq7cOesM5m';

if (password_verify('admin', $hash)) {
    echo 'La password è corretta';
} else {
    echo 'La password non è corretta';
}


echo PHP_EOL;
